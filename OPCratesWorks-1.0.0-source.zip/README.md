# OPCratesWorks

Custom Paper 1.21.1 plugin for:
- OP Crate GUI
- Custom OP Crate Keys
- Custom Void Saber
- Custom Void Armor
- Armor passive effects
- Saber ability
- Admin give commands

## Build
Requirements:
- Java 21
- Maven
- Paper 1.21.1 server

Windows:
1. Install Java 21 and Maven.
2. Open a terminal in this folder.
3. Run: `mvn clean package`
4. Get the jar from `target/opcrates-works-1.0.0.jar`
5. Put it in your server's `plugins` folder.
6. Restart the server.

## Commands
- `/opcrates help`
- `/opcrates givekey <player> [amount]`
- `/opcrates crate <player>`
- `/opcrates saber <player>`
- `/opcrates armor <player>`
- `/opcrates reload`

Permission: `opcrates.admin`

## Using the crate
Place any CHEST. Right-click it with an OP CRATE KEY.
The key is consumed and the plugin opens the OP CRATE reward GUI. Click OPEN CRATE or a reward slot to receive a randomized OP reward. Full Void Armor grants passive Resistance, Speed and Strength.

## Important
This plugin uses normal Bukkit/Paper APIs and PersistentDataContainer item tags. It does not require Skript, ItemsAdder, Oraxen, MythicMobs, or NMS.
